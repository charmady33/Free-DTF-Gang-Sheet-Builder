const { contextBridge, ipcRenderer } = require('electron');

// Safe bridge for file-based job storage in the desktop app.
contextBridge.exposeInMainWorld('gangNative', {
  dir:    ()            => ipcRenderer.invoke('jobs:dir'),
  list:   ()            => ipcRenderer.invoke('jobs:list'),
  read:   (path)        => ipcRenderer.invoke('jobs:read', path),
  save:   (name, text)  => ipcRenderer.invoke('jobs:save', { name, text }),
  saveAs: (name, text)  => ipcRenderer.invoke('jobs:saveAs', { name, text }),
  del:    (path)        => ipcRenderer.invoke('jobs:del', path),
});
