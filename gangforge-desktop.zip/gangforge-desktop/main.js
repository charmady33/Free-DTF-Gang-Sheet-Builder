const { app, BrowserWindow, Menu, dialog, ipcMain } = require('electron');
const path = require('path');
const fs = require('fs');

// ---- default jobs folder: <Documents>/GangForge Jobs ----
function jobsDir() {
  const dir = path.join(app.getPath('documents'), 'GangForge Jobs');
  try { fs.mkdirSync(dir, { recursive: true }); } catch (_) {}
  return dir;
}
function safeName(name) {
  return String(name || 'Untitled').replace(/[\\/:*?"<>|]+/g, '_').slice(0, 120);
}

ipcMain.handle('jobs:dir', () => jobsDir());

ipcMain.handle('jobs:list', () => {
  const dir = jobsDir();
  let out = [];
  try {
    for (const f of fs.readdirSync(dir)) {
      if (!f.toLowerCase().endsWith('.gangjob.json')) continue;
      const full = path.join(dir, f);
      let meta = {};
      try {
        const j = JSON.parse(fs.readFileSync(full, 'utf8'));
        meta = { name: j.name || f.replace(/\.gangjob\.json$/i, ''), pieceCount: j.pieceCount, designs: (j.designs || []).slice(0, 1) };
      } catch (_) { meta = { name: f.replace(/\.gangjob\.json$/i, '') }; }
      out.push(Object.assign(meta, { path: full, mtime: fs.statSync(full).mtimeMs }));
    }
  } catch (_) {}
  return out;
});

ipcMain.handle('jobs:read', (e, p) => {
  try { return fs.readFileSync(p, 'utf8'); } catch (_) { return null; }
});

ipcMain.handle('jobs:save', (e, { name, text }) => {
  const dir = jobsDir();
  const file = path.join(dir, safeName(name) + '.gangjob.json');
  fs.writeFileSync(file, text, 'utf8');
  return { name: safeName(name), path: file };
});

ipcMain.handle('jobs:saveAs', async (e, { name, text }) => {
  const win = BrowserWindow.getFocusedWindow();
  const res = dialog.showSaveDialogSync(win, {
    title: 'Save Job As',
    defaultPath: path.join(jobsDir(), safeName(name) + '.gangjob.json'),
    filters: [{ name: 'GangForge Job', extensions: ['gangjob.json', 'json'] }],
  });
  if (!res) return null;
  fs.writeFileSync(res, text, 'utf8');
  return { name: path.basename(res).replace(/\.gangjob\.json$|\.json$/i, ''), path: res };
});

ipcMain.handle('jobs:del', (e, p) => {
  try { fs.unlinkSync(p); } catch (_) {}
  return true;
});

function createWindow() {
  const win = new BrowserWindow({
    width: 1440,
    height: 900,
    minWidth: 1024,
    minHeight: 640,
    backgroundColor: '#16171b',
    title: 'GangForge',
    icon: path.join(__dirname, 'build', 'icon.png'),
    webPreferences: {
      preload: path.join(__dirname, 'preload.js'),
      contextIsolation: true,
      nodeIntegration: false,
    },
  });

  win.loadFile(path.join(__dirname, 'index.html'));

  // Save dialog for exported PNG / ZIP downloads
  win.webContents.session.on('will-download', (event, item) => {
    const name = item.getFilename();
    const save = dialog.showSaveDialogSync(win, { defaultPath: name });
    if (save) item.setSavePath(save); else item.cancel();
  });

  return win;
}

app.whenReady().then(() => {
  Menu.setApplicationMenu(null);
  createWindow();
  app.on('activate', () => { if (BrowserWindow.getAllWindows().length === 0) createWindow(); });
});

app.on('window-all-closed', () => { if (process.platform !== 'darwin') app.quit(); });
