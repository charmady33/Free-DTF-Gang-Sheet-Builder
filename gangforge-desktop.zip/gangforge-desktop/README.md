# GangForge — Desktop App

This packages the GangForge gang sheet builder into a real desktop application
(its own window, Start-menu / Applications entry, and an installer). It runs
fully offline — no internet needed.

## What's in this folder
- `index.html` — the entire app (self-contained, no external libraries)
- `main.js` — the Electron wrapper that opens it in a desktop window
- `package.json` — build configuration

---

## Option A — Just run it (no build)
You don't actually need to build an installer to use it. Because `index.html`
is self-contained, you can simply **double-click `index.html`** and it opens in
your web browser, fully working and offline. The steps below are only if you
want a true installed desktop app with its own icon and window.

---

## Option B — Build a real desktop app

### 1. Install Node.js (one time)
Download and install the LTS version from https://nodejs.org
(this gives you the `npm` command used below).

### 2. Open a terminal in this folder
- Windows: open the folder, type `cmd` in the address bar, press Enter.
- Mac: right-click the folder → "New Terminal at Folder".

### 3. Install dependencies (one time)
```
npm install
```

### 4. Run the app to try it
```
npm start
```

### 5. Build an installer
Build for the operating system you are currently on:
```
npm run dist
```
The finished installer appears in the **`dist/`** folder:
- Windows → `GangForge Setup 1.0.0.exe`
- Mac → `GangForge-1.0.0.dmg`
- Linux → `GangForge-1.0.0.AppImage`

> Note: you can only build a Windows installer on Windows, a Mac installer on a
> Mac, etc. (cross-building requires extra setup). Build on each OS you need.

---

## Updating the app later
If you get a new version of the builder, just replace `index.html` in this
folder with the new file and run `npm run dist` again.

## Notes
- Saved jobs are stored locally on the machine (per user account). They are not
  shared between computers — use the in-app **Export / Import job file** to move
  a job to another machine.
- Exports are full-resolution PNGs at your chosen DPI (300 by default); multiple
  sheets come out as a ZIP.
